export function createTestUser() {
  const timestamp = Date.now();

  return {
    username: `gabriela_${timestamp}`,
    email: `gabriela_${timestamp}@test.com`,
    password: "Password123",
  };
}

export const invalidUser = {
  email: "usuario_inexistente@test.com",
  password: "senhaerrada123",
};